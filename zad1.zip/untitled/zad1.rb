# Array with available choices
choices = ["rock", "paper", "scissors"]

# Computer's choice
computer_choice = choices.sample

# Ask the user for their choice
puts "Choose a move (rock, paper, or scissors):"
user_choice = gets.chomp.downcase

# Check if the user's input is valid
unless choices.include?(user_choice)
  puts "Please choose a valid move (rock, paper, or scissors)!"
  exit
end

# Display the user's and computer's choices
puts "Your choice: #{user_choice}"
puts "Computer's choice: #{computer_choice}"

# Check the game result
if user_choice == computer_choice
  puts "It's a tie!"
elsif (user_choice == "rock" && computer_choice == "scissors")
  (user_choice == "scissors" && computer_choice == "paper")
  (user_choice == "paper" && computer_choice == "rock")
  puts "You win!"
else
  puts "You lose!"
end